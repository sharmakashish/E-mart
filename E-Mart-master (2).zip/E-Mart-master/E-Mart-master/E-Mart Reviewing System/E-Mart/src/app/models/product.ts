export class Product{
    code: number=0;
    productName: string='';
    brand: string='';
    imageLink: string='';
    price:number=0;
}