export class user{
    userEmail: string='';
    firstName: string='';
    lastName: string='';
    userPassword: string='';
    userRole:string='';
}