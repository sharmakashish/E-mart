export class Review{
    id:number=0;
    code: number=0;
    heading: string='';
    rating: number=0;
    comment: string='';
    userName:string='';
    approved:boolean=false;
}