package com.assignment12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularRestapiApplication.class, args);
	}

}
